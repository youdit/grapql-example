# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['graphql']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.87.0,<0.88.0',
 'strawberry-graphql[debug-server]>=0.142.2,<0.143.0']

setup_kwargs = {
    'name': 'graphql',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Udit',
    'author_email': 'udit.singh98@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
